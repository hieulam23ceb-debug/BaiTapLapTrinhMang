import kotlin.properties.ReadWriteProperty
import kotlin.reflect.KProperty

// Lớp cha SmartDevice: đại diện cho thiết bị thông minh chung
open class SmartDevice(val name: String, val category: String) {
    var deviceStatus = "online"   // trạng thái thiết bị (online, on, off)
        protected set             // chỉ lớp con mới thay đổi được, bên ngoài chỉ đọc

    open val deviceType = "unknown"  // loại thiết bị (mặc định unknown)

    // Bật thiết bị
    open fun turnOn() {
        deviceStatus = "on"
    }

    // Tắt thiết bị
    open fun turnOff() {
        deviceStatus = "off"
    }

    // In thông tin thiết bị
    fun printDeviceInfo() {
        println("Device name: $name, category: $category, type: $deviceType")
    }
}

// Lớp SmartTvDevice kế thừa SmartDevice
class SmartTvDevice(deviceName: String, deviceCategory: String) :
    SmartDevice(name = deviceName, category = deviceCategory) {
    override val deviceType = "Smart Tv"

    // Thuộc tính điều chỉnh âm lượng và kênh có giới hạn (0..100 và 1..200)
    private var speakerVolume by RangeRegulator(initialValue = 0, minValue = 0, maxValue = 100)
    private var channelNumber by RangeRegulator(initialValue = 0, minValue = 1, maxValue = 200)

    // Bật TV
    override fun turnOn() {
        super.turnOn()
        speakerVolume = 2     // âm lượng mặc định khi bật
        channelNumber = 1     // kênh mặc định khi bật
        println("$name is turned on. Speaker volume is set to $speakerVolume and channel number is set to $channelNumber.")
    }

    // Tắt TV
    override fun turnOff() {
        super.turnOff()
        speakerVolume = 0
        channelNumber = 0
        println("$name is turned off.")
    }

    // Tăng âm lượng
    fun increaseSpeakerVolume() {
        if (deviceStatus == "on") {
            speakerVolume++
            println("Speaker volume increased to $speakerVolume.")
        }
    }

    // Giảm âm lượng
    fun decreaseVolume() {
        if (deviceStatus == "on" && speakerVolume > 0) {
            speakerVolume--
            println("Speaker volume decreased to $speakerVolume.")
        }
    }

    // Chuyển sang kênh tiếp theo
    fun nextChannel() {
        if (deviceStatus == "on") {
            channelNumber++
            println("Channel changed to $channelNumber.")
        }
    }

    // Quay lại kênh trước
    fun previousChannel() {
        if (deviceStatus == "on" && channelNumber > 1) {
            channelNumber--
            println("Channel changed to $channelNumber.")
        }
    }
}

// Lớp SmartLightDevice kế thừa SmartDevice
class SmartLightDevice(deviceName: String, deviceCategory: String) :
    SmartDevice(name = deviceName, category = deviceCategory) {
    override val deviceType = "Smart Light"

    // Độ sáng của đèn (0..100)
    private var brightnessLevel by RangeRegulator(initialValue = 0, minValue = 0, maxValue = 100)

    override fun turnOn() {
        super.turnOn()
        brightnessLevel = 2
        println("$name turned on. The brightness level is $brightnessLevel.")
    }

    override fun turnOff() {
        super.turnOff()
        brightnessLevel = 0
        println("$name turned off.")
    }

    fun increaseBrightness() {
        if (deviceStatus == "on") {
            brightnessLevel++
            println("Light brightness increased to $brightnessLevel.")
        }
    }

    fun decreaseBrightness() {
        if (deviceStatus == "on" && brightnessLevel > 0) {
            brightnessLevel--
            println("Light brightness decreased to $brightnessLevel.")
        }
    }
}

// Lớp SmartHome: quản lý nhiều thiết bị trong nhà
class SmartHome(
    private val smartTvDevice: SmartTvDevice,
    private val smartLightDevice: SmartLightDevice
) {
    var deviceTurnOnCount = 0   // đếm số thiết bị đang bật
        private set

    // Bật TV (nếu chưa bật thì tăng counter)
    fun turnOnTV() {
        if (smartTvDevice.deviceStatus != "on") {
            smartTvDevice.turnOn()
            deviceTurnOnCount++
        }
    }

    // Tắt TV (nếu đang bật thì giảm counter)
    fun turnOffTV() {
        if (smartTvDevice.deviceStatus == "on") {
            smartTvDevice.turnOff()
            deviceTurnOnCount--
        }
    }

    // Tăng âm lượng TV
    fun increaseTvVolume() {
        if (smartTvDevice.deviceStatus == "on") {
            smartTvDevice.increaseSpeakerVolume()
        }
    }

    // Giảm âm lượng TV
    fun decreaseTvVolume() {
        if (smartTvDevice.deviceStatus == "on") {
            smartTvDevice.decreaseVolume()
        }
    }

    // Chuyển kênh kế tiếp
    fun changeTvChannelToNext() {
        if (smartTvDevice.deviceStatus == "on") {
            smartTvDevice.nextChannel()
        }
    }

    // Quay lại kênh trước
    fun changeTvChannelToPrevious() {
        if (smartTvDevice.deviceStatus == "on") {
            smartTvDevice.previousChannel()
        }
    }

    // Bật đèn
    fun turnOnLight() {
        if (smartLightDevice.deviceStatus != "on") {
            smartLightDevice.turnOn()
            deviceTurnOnCount++
        }
    }

    // Tắt đèn
    fun turnOffLight() {
        if (smartLightDevice.deviceStatus == "on") {
            smartLightDevice.turnOff()
            deviceTurnOnCount--
        }
    }

    // Tăng độ sáng
    fun increaseLightBrightness() {
        if (smartLightDevice.deviceStatus == "on") {
            smartLightDevice.increaseBrightness()
        }
    }

    // Giảm độ sáng
    fun decreaseLightBrightness() {
        if (smartLightDevice.deviceStatus == "on") {
            smartLightDevice.decreaseBrightness()
        }
    }

    // In thông tin TV
    fun printSmartTvInfo() {
        smartTvDevice.printDeviceInfo()
    }

    // In thông tin đèn
    fun printSmartLightInfo() {
        smartLightDevice.printDeviceInfo()
    }

    // Tắt tất cả thiết bị
    fun turnOffAllDevice() {
        turnOffTV()
        turnOffLight()
    }
}

// Lớp hỗ trợ RangeRegulator: giữ giá trị trong phạm vi cho phép
class RangeRegulator(
    initialValue: Int,
    private val minValue: Int,
    private val maxValue: Int
) : ReadWriteProperty<Any?, Int> {
    private var fieldData = initialValue

    override fun getValue(thisRef: Any?, property: KProperty<*>): Int {
        return fieldData
    }

    override fun setValue(thisRef: Any?, property: KProperty<*>, value: Int) {
        if (value in minValue..maxValue) {   // chỉ gán khi trong phạm vi
            fieldData = value
        }
    }
}

fun main() {
    // Tạo TV và đèn
    val smartTv = SmartTvDevice("Android TV", "Entertainment")
    val smartLight = SmartLightDevice("Google Light", "Utility")
    val smartHome = SmartHome(smartTv, smartLight)

    // Điều khiển TV
    smartHome.turnOnTV()
    smartHome.increaseTvVolume()
    smartHome.decreaseTvVolume()
    smartHome.changeTvChannelToNext()
    smartHome.changeTvChannelToPrevious()
    smartHome.printSmartTvInfo()

    // Điều khiển đèn
    smartHome.turnOnLight()
    smartHome.increaseLightBrightness()
    smartHome.decreaseLightBrightness()
    smartHome.printSmartLightInfo()

    // Kiểm tra số thiết bị đang bật
    println("Devices currently ON: ${smartHome.deviceTurnOnCount}")
    smartHome.turnOffAllDevice()
    println("Devices currently ON: ${smartHome.deviceTurnOnCount}")
}
